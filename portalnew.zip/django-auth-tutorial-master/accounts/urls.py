from django.conf.urls import url

from . import views

#app_name='accounts'
urlpatterns = [
    url('search/', views.search, name='search'),
    url('descriptor/', views.descriptor.as_view(), name='descriptor'),
]
