from django.db import models
class compound(models.Model):
    name=models.CharField(max_length=250)
    
    def __str__(self):
        return self.name
class detail(models.Model):
    det=models.ForeignKey(compound,on_delete=models.CASCADE)
    name=models.CharField(max_length=250)
    smile=models.CharField(max_length=250)
    density=models.CharField(max_length=230)
    bp=models.CharField(max_length=230)
    mp=models.CharField(max_length=230)
    hof=models.CharField(max_length=230)
    hoc=models.CharField(max_length=230)
    mw=models.CharField(max_length=230)
    mf=models.CharField(max_length=230)
    state=models.CharField(max_length=230,default=" ")
    oxygenb=models.IntegerField(default=0)
    
    def __str__(self):
        return self.name
