from django.contrib import admin
from .models import compound,detail

from import_export.admin import ImportExportModelAdmin
@admin.register(compound)
@admin.register(detail)

class ViewAdmin(ImportExportModelAdmin):
    pass
