from django.contrib.auth.forms import UserCreationForm
from django.urls import reverse_lazy
from django.views import generic
from django.shortcuts import get_object_or_404, render
from app.models import name,detail
from django.db import models
from django.db.models import Q
from django.db.models import F
# Create your views here.
l=[]
for i in range(0,1001):
    l.append(i)
def tran(request):        
    if request.method == 'GET':       
        book_name =  request.GET.get('accno')
        book_names =  request.GET.get('amt')
        
        
            
        try:
            status = detail.objects.filter(accno__exact=book_name)
            status1 = detail.objects.filter(accno__exact=book_name).update(amt=F("amt") -book_names)	
                          
        except detail.DoesNotExist:
            status = None
        return render(request,"tran.html",{"books":status})   
    else:
        return render(request,"tran.html",{})
