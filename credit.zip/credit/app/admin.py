from django.contrib import admin
from .models import name,detail
admin.site.register(name)
admin.site.register(detail)
# Register your models here.
