from django.contrib.auth.forms import UserCreationForm
from django.urls import reverse_lazy
from django.views import generic
from django.shortcuts import get_object_or_404, render
from accounts.models import compound,detail
from django.db import models

class SignUp(generic.CreateView):
    form_class = UserCreationForm
    success_url = reverse_lazy('login')
    template_name = 'signup.html'
def search(request):        
    if request.method == 'GET':       
        book_name =  request.GET.get('search')        
        try:
            status = detail.objects.filter(name__icontains=book_name)
        except detail.DoesNotExist:
            status = None
        return render(request,"search.html",{"books":status})
    else:
        return render(request,"search.html",{})
class descriptor(generic.ListView):
    template_name= 'descriptor.html'

    def get_queryset(self):
        return detail.objects.all()
